
import java.awt.image.BufferedImage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lokesh
 */
public class Book {
    private String title,isbn;
    private int edition,price,handNo;
    private BufferedImage front,back,side;
    Book(){
        
    }
    Book(String title,String isbn,int edition,int price,int handNo,
            BufferedImage front,BufferedImage back,BufferedImage side){
        this.title=title;
        this.edition=edition;
        this.front=front;
        this.back=back;
        this.side=side;
        this.price=price;
        this.isbn=isbn;
        this.handNo=handNo;
    }
    static void main(String args[]){
        
    }
    
}
